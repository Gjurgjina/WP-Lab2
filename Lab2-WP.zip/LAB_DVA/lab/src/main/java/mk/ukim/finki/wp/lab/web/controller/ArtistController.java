package mk.ukim.finki.wp.lab.web.controller;

import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.service.ArtistService;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@Controller
public class ArtistController {
    private final ArtistService artistService;
    private final SongService songService;

    public ArtistController(ArtistService artistService, SongService songService) {
        this.artistService = artistService;
        this.songService = songService;
    }
   @GetMapping("/artist")
    public String getArtistPage(@RequestParam(required = false) String trackId, Model model)
   {
       // Додавање на листата на артисти и идентификаторот на песната во моделот
       model.addAttribute("artistList", artistService.listArtists());
       model.addAttribute("trackId", trackId != null ? trackId : "");
       return "artistsList";
   }

    @PostMapping("/artist")
    public String addArtistToSong(@RequestParam Long artistId, @RequestParam Long trackId) {
        Artist artistOptional = artistService.findById(artistId);
        Song songOptional = songService.findByTrackId(trackId);

        if (artistOptional!=null && songOptional!=null) {
            if (!songOptional.getPerformers().contains(artistOptional)) {
                songService.addArtistToSong(artistService.findById(artistOptional.getId()), songService.findByTrackId(songOptional.getTrackId()));
            }
            return "redirect:/songDetails/" + songOptional.getTrackId();
        } else {
            // Handle the case where author or book is not found
            return "redirect:/songs?error=Author or Book not found";
        }
    }
}
