package mk.ukim.finki.wp.lab.model;

import lombok.Data;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Data
public class Song {

    private Long trackId;

    private String title;

    private String genre;

    private int releaseYear;

    private Album album;

    private List<Artist> performers;

    public Song(String title, String genre, int releaseYear,Album album) {
        this.trackId=(long)(Math.random()*1000);
        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;
        performers = new ArrayList<>();
        this.album=album;
    }

    public void addPerformer(Artist performer) {
        performers.add(performer);
    }

}
