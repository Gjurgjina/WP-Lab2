package mk.ukim.finki.wp.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Artist> artistList=new ArrayList<Artist>();

    public static List<Song> songList=new ArrayList<Song>();
    public static List<Album> albumList=new ArrayList<Album>();
    @PostConstruct
    public void init()
    {
        artistList.add(new Artist(1L,"Jenifer","Lopez","Voedno e i odlichna glumica"));
        artistList.add(new Artist(2L,"Beyonce","Knowles-Carter","The goddess"));
        artistList.add(new Artist(3L,"Bruno","Mars","Roden na Hawaii"));
        artistList.add(new Artist(4L,"Justin","Timberlake","Eden od najdobrite pejaci, odlicni pesni"));
        artistList.add(new Artist(5L,"Miley","Cyrus","Tinejdzerska kralica"));


        albumList.add(new Album("Album1","Dance-pop Latin","2003"));
        albumList.add(new Album("Album2","Pop","2006"));
        albumList.add(new Album("Album3","Pop R&B hiphop","2009"));
        albumList.add(new Album("Album4","Disco pop rock funk","2013"));
        albumList.add(new Album("Album5","Pop R&B","2023"));

        songList.add(new Song("On the floor","Dance-pop Latin",2011,albumList.get(0)));
        songList.add(new Song("Crazy in love","Pop R&B hiphop",2003,albumList.get(1)));
        songList.add(new Song("Grenade","Pop",2010,albumList.get(2)));
        songList.add(new Song("Mirrors","Pop R&B",2011,albumList.get(3)));
        songList.add(new Song("Flowers","Disco pop rock funk",2023,albumList.get(4)));

    }
}
