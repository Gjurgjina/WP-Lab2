package mk.ukim.finki.wp.lab.web.controller;

import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Exception.AlbumNotFoundException;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.service.AlbumService;
import mk.ukim.finki.wp.lab.service.ArtistService;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class SongController {
    //sakam da vratam nekoja strana i nekoe view

    private final SongService songService;
    private final AlbumService albumService;
    private final ArtistService artistService;

    public SongController(SongService songService, AlbumService albumService, ArtistService artistService) {
        this.songService = songService;
        this.albumService = albumService;
        this.artistService = artistService;
    }

    //i bez parametar kje se povika-required=false
    @GetMapping("/songs")
    public String getSongsPage(@RequestParam(required = false) String error,
                               Model model)
    {
        if(error!=null && !error.isEmpty())
        {
            model.addAttribute("hasError",true);
            model.addAttribute("error",error);
        }
        model.addAttribute("songs",this.songService.listSongs());
        return "listSongs";
    }
    @GetMapping("/songs/add-form")
    public String getAddSongPage(Model model){
        List<Artist> artists = this.artistService.listArtists();
        List<Album> albums = this.albumService.findAll();
        model.addAttribute("artists", artists);
        model.addAttribute("albums", albums);
        return "add-song";
    }
     @GetMapping("/songs/delete/{id}")
    public String deleteSong(@PathVariable Long id)
     {
         this.songService.deleteById(id);
         return "redirect:/songs";
     }

    @GetMapping("/songs/edit-form/{id}")
    public String getEditSongForm(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes){

        Song song = this.songService.findByTrackId(id);
        if(song==null)
        {
            redirectAttributes.addFlashAttribute("error", "Song with ID " + id + " not found.");
            return "redirect:/songs";
        }
        List<Artist> artists = this.artistService.listArtists();
        List<Album> albums = this.albumService.findAll();
        model.addAttribute("song", song);
        model.addAttribute("artists", artists);
        model.addAttribute("albums", albums);
        return "add-song";
        //return "redirect:/songs?error=SongNotFound";
    }
     @GetMapping("/songs/edit/{songId}")
    public String editSong(@PathVariable Long songId,
                           @RequestParam(required = false) String title,
                           @RequestParam(required = false) String genre,
                           @RequestParam(required = false) Integer releaseYear,
                           @RequestParam(required = false) Long albumId){
     Song song=this.songService.findByTrackId(songId);
     song.setTitle(title);
     song.setGenre(genre);
     song.setReleaseYear(releaseYear);
     song.setAlbum(albumService.findById(albumId).orElseThrow(() -> new AlbumNotFoundException(albumId)));
     return "redirect:/songs";
     }

    @PostMapping("/songs/add")
    public String saveSong(@RequestParam(required = false) String title,
                           @RequestParam(required = false) Long trackId,
                           @RequestParam(required = false) String genre,
                           @RequestParam(required = false) Integer releaseYear,
                           @RequestParam(required = false) Long albumId) {
        Album album = albumService.findById(albumId).orElseThrow(() -> new AlbumNotFoundException(albumId));
        if(trackId==null)
        {
            this.songService.save(title,genre,releaseYear,album);
            return "redirect:/songs";
        }
        Song song = this.songService.findByTrackId(trackId);
        song.setTitle(title);
        song.setGenre(genre);
        song.setReleaseYear(releaseYear);
        song.setAlbum(albumService.findById(albumId).orElseThrow(() -> new AlbumNotFoundException(albumId)));
        return "redirect:/songs";
    }
}
