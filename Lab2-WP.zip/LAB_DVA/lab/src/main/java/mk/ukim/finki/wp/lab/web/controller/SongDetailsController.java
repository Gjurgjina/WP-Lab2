package mk.ukim.finki.wp.lab.web.controller;

import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import mk.ukim.finki.wp.lab.service.ArtistService;
import mk.ukim.finki.wp.lab.service.SongService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class SongDetailsController {
    private final SongService songService;
    private final ArtistService artistService;

    public SongDetailsController(SongService songService, ArtistService artistService) {
        this.songService = songService;
        this.artistService = artistService;
    }
    @GetMapping("/songDetails/{songId}")
    public String getBookDetailsPage(@PathVariable Long songId, Model model) {
        model.addAttribute("song", songService.findByTrackId(songId));
        return "songDetails";
    }

//    @PostMapping
//    public String addArtistToSong(@RequestParam Long trackId,
//                                  @RequestParam Long artistId, Model model) {
//        // Наоѓање на песната и артистот според ID
//        Song song = songService.findByTrackId(trackId);
//        Artist artist = artistService.findById(artistId);
//
//        if (song != null && artist != null) {
//            song.addPerformer(artist);
//            artist.addSongToArtist(song);
//        }
//
//        // Поставување на податоците во моделот
//        model.addAttribute("song", song);
//        model.addAttribute("artist", artist);
//        return "songDetails";
//    }
}
