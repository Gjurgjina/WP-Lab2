package mk.ukim.finki.wp.lab.repository;

import mk.ukim.finki.wp.lab.bootstrap.DataHolder;
import mk.ukim.finki.wp.lab.model.Album;
import mk.ukim.finki.wp.lab.model.Artist;
import mk.ukim.finki.wp.lab.model.Song;
import org.springframework.stereotype.Repository;

import javax.xml.crypto.Data;
import java.util.List;
import java.util.Optional;

@Repository
public class SongRepository {
    public List<Song> findAll(){
        return DataHolder.songList;
    }
    public Song findByTrackId(Long trackId)
    {
        return DataHolder.songList.stream().filter(r->r.getTrackId().equals(trackId)).findFirst().orElse(null);
        //ako ne najde pesna so dadeniot trackid vrati null
    }
    public Artist addArtistToSong(Artist artist, Song song)
    {
      Song existingSong=DataHolder.songList.stream()
              .filter(s->s.getTrackId().equals(song.getTrackId()))
              .findFirst()
              .orElse(null);
      if(existingSong!=null)
      {
          existingSong.addPerformer(artist);
          return artist;
      }
      return null;
    }
   public Optional<Song> save(String title, String genre, Integer releaseYear, Album album)
   {
       DataHolder.songList.removeIf(i -> i.getTitle().equals(title));
       Song song=new Song(title,genre,releaseYear,album);
       DataHolder.songList.add(song);
       return Optional.of(song);//za da izbegneme null mora Optional
   }
   public void deleteById(Long id)
   {
       DataHolder.songList.removeIf(i -> i.getTrackId().equals(id));
   }
}
